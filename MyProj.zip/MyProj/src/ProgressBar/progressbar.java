
package ProgressBar;

import myui.Login;
import java.util.logging.Level;
import java.util.logging.Logger;


public class progressbar {


    public static void main(String args[]) {
        // TODO code application logic here
        ProgressBarFrame pr = new ProgressBarFrame();
        Login If = new Login();
        pr.setVisible(true);
        
        for (int i = 1; i<=100; ++i) {
            try {
                Thread.sleep(80);
                pr.ProgressBar.setValue(i);
                
                if (i==1) {
                    pr.loading.setText("Preparing");
                } else if (i==5) {
                    pr.loading.setText("Preapring.");
                }
                
                if (i==100) {
                    pr.setVisible(false);
                    If.setVisible(true);
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(progressbar.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
