
package myui;

import myui.Login;
import javax.swing.*;
import config.config;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class btn extends javax.swing.JFrame {


    public btn() {
        this.setUndecorated(true);
        initComponents();
        this.setLocationRelativeTo(null);
        
        btn_signup.addActionListener(e -> {
            insertData(); // Call the insert function
            
        });
            
    }
    
     private void insertData() {
        // Step 1: Get user input from text fields
        String username = userField.getText();
        String email = emailField.getText();
        String password = String.valueOf(newPasswordField.getPassword());
        String confirm1 = String.valueOf(enterPass2.getPassword());

        // Step 3: Check if all fields are filled
        if (username.isEmpty() ||email.isEmpty() || password.isEmpty() || confirm1.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill out all fields!", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        if (!password.equals(confirm1)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match please try again", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        if (!Terms.isSelected()) {
            JOptionPane.showMessageDialog(this, "You must agree to the terms and conditions", "Error", JOptionPane.ERROR_MESSAGE);
            return;       
                
        }

        if (!email.contains("@gmail.com")) {
            JOptionPane.showMessageDialog(null, "Please enter a valid Gmail account", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Step 4: Connect to the database and insert data
        try {
            /*int age = Integer.parseInt(ageText);*/ // convert age to number
            Connection conn = config.dbConnection(); // connect to PostgreSQL

            String sql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,username);
            pstmt.setString(3,email);
            pstmt.setString(2,new String(password));
            pstmt.executeUpdate(); // Run the SQL command

            JOptionPane.showMessageDialog(this, "Succcesfully Registered" + "\n"+ "Username: " + username + "\n" + "Email: " + email, "Succesfully Registered", JOptionPane.PLAIN_MESSAGE);
            new btn().setVisible(true);
            this.dispose();

            // Optional: clear the form after success
            userField.setText("");
            emailField.setText("");
            newPasswordField.setText("");
            conn.close();
           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
     }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        emailField = new javax.swing.JTextField();
        userField = new javax.swing.JTextField();
        enterPass2 = new javax.swing.JPasswordField();
        newPasswordField = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        btn_signup = new javax.swing.JButton();
        Terms = new javax.swing.JCheckBox();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(400, 500));
        getContentPane().setLayout(null);

        emailField.setBackground(new java.awt.Color(100, 90, 150));
        emailField.setForeground(new java.awt.Color(255, 255, 255));
        emailField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 90, 150), 3));
        getContentPane().add(emailField);
        emailField.setBounds(50, 210, 300, 30);

        userField.setBackground(new java.awt.Color(100, 90, 150));
        userField.setForeground(new java.awt.Color(255, 255, 255));
        userField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 90, 150), 3));
        getContentPane().add(userField);
        userField.setBounds(50, 140, 300, 30);

        enterPass2.setBackground(new java.awt.Color(100, 90, 150));
        enterPass2.setForeground(new java.awt.Color(255, 255, 255));
        enterPass2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 90, 150), 3));
        enterPass2.setEchoChar('\u2022');
        getContentPane().add(enterPass2);
        enterPass2.setBounds(50, 350, 300, 30);

        newPasswordField.setBackground(new java.awt.Color(100, 90, 150));
        newPasswordField.setForeground(new java.awt.Color(255, 255, 255));
        newPasswordField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(100, 90, 150), 3));
        newPasswordField.setEchoChar('\u2022');
        getContentPane().add(newPasswordField);
        newPasswordField.setBounds(50, 280, 300, 30);

        jButton1.setBackground(new java.awt.Color(100, 90, 150));
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Log In");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(270, 450, 72, 30);

        btn_signup.setBackground(new java.awt.Color(100, 90, 150));
        btn_signup.setForeground(new java.awt.Color(255, 255, 255));
        btn_signup.setText("Sign Up");
        getContentPane().add(btn_signup);
        btn_signup.setBounds(50, 420, 72, 30);

        Terms.setText("agree to the terms and conditions");
        Terms.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TermsActionPerformed(evt);
            }
        });
        getContentPane().add(Terms);
        Terms.setBounds(50, 390, 230, 20);

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Confirm Password");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(50, 330, 110, 16);

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Password");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(50, 260, 60, 16);

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Email");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(50, 190, 60, 16);

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Username");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(50, 120, 60, 16);

        jLabel2.setFont(new java.awt.Font("Serif", 0, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SIGN UP");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(130, 60, 150, 50);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/myui/My Background.jpg"))); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.setPreferredSize(new java.awt.Dimension(400, 500));
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 400, 500);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        Login bt = new Login();
        bt.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void TermsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TermsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TermsActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(btn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(btn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(btn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(btn.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new btn().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox Terms;
    private javax.swing.JButton btn_signup;
    private javax.swing.JTextField emailField;
    private javax.swing.JPasswordField enterPass2;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPasswordField newPasswordField;
    private javax.swing.JTextField userField;
    // End of variables declaration//GEN-END:variables
}
