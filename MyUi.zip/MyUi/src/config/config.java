
package config;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.SQLException;

public class config {
    
        public static Connection dbConnection() {
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            
            String url = "jdbc:postgresql://localhost:5432/testpractice";
            String user = "postgres";
            String password = "2478Ka!ser";
            
            conn = DriverManager.getConnection(url, user, password);
            return conn;
            
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "No Data Connection" + e.getMessage());
            
        } catch (SQLException e) {
            // This error means the connection failed (wrong URL, user, or password).
            JOptionPane.showMessageDialog(null, "No Data Connection: " + e.getMessage(), "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    return null;
    }
    



    public static void main(String args[]) {
        // TODO code application logic here
        Connection testConn = dbConnection();
        if (testConn != null) {
            try {
                testConn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
